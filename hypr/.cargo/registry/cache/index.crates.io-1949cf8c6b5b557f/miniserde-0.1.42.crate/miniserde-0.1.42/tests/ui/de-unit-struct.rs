use miniserde::Deserialize;

#[derive(Deserialize)]
struct UnitStruct;

fn main() {}
